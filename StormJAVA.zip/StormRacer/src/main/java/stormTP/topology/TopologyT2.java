package stormTP.topology;

import org.apache.storm.Config;

import org.apache.storm.StormSubmitter;
import org.apache.storm.topology.TopologyBuilder;
import stormTP.operator.MasterInputStreamSpout;
import stormTP.operator.MyTortoiseBolt;
import stormTP.operator.Exit2Bolt;

public class TopologyT2 {
	
	public static void main(String[] args) throws Exception {
	//@TODO
	
	
	
	
	}
}

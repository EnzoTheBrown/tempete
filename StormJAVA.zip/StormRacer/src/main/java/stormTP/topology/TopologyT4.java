package stormTP.topology;


import org.apache.storm.Config;

import org.apache.storm.StormSubmitter;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.topology.base.BaseWindowedBolt.Count;

import stormTP.operator.ComputeBonusBolt;
import stormTP.operator.Exit4Bolt;
import stormTP.operator.GiveRankBolt;
import stormTP.operator.MasterInputStreamSpout;
import stormTP.operator.MyTortoiseBolt;

public class TopologyT4 {
	
	public static void main(String[] args) throws Exception {
	
	//@TODO
	
	
	
	
    	
		
	}
}

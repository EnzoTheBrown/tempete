package stormTP.topology;

import org.apache.storm.Config;

import org.apache.storm.StormSubmitter;
import org.apache.storm.topology.base.BaseWindowedBolt.Duration;
import org.apache.storm.topology.TopologyBuilder;
import java.util.concurrent.TimeUnit;

import stormTP.operator.Exit6Bolt;
import stormTP.operator.GiveRankBolt;
import stormTP.operator.MasterInputStreamSpout;
import stormTP.operator.MyTortoiseBolt;
import stormTP.operator.RankEvolutionBolt;

public class TopologyT6 {
	
public static void main(String[] args) throws Exception {
    	
	//@TODO
	
	
	
	
        
    }

}
